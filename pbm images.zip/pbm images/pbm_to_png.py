import numpy as np
from PIL import Image

def convert_ppm_to_png(pbm_file, png_file):
    # Read PPM file
    with open(pbm_file, 'r') as f:
        # Read header
        magic = f.readline().strip()
        if magic != 'P3':
            raise ValueError('Not a PBM P3 file')

        # Skip comments if any
        line = f.readline()
        while line.startswith('#'):
            line = f.readline()

        # Read dimensions
        width, height = map(int, line.split())

        # Read max color value
        max_val = int(f.readline())

        # Read pixel data
        pixels = []
        for line in f:
            pixels.extend(map(int, line.split()))

    # Convert to numpy array and reshape
    pixels = np.array(pixels, dtype=np.uint8)
    pixels = pixels.reshape((height, width, 3))

    # Create and save image
    image = Image.fromarray(pixels)
    image.save(png_file)

if __name__ == '__main__':
    convert_ppm_to_png('Mandelbrot_output.pbm', 'Mandelbrot_output.png')
    convert_ppm_to_png('Julia_output.pbm', 'Julia_output.png')